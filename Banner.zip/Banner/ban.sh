R='\033[0;31m'
G='\033[0;32m'
clear

#logo
figlet Ghost | lolcat


echo -e $R"					Tool by Daham"
echo -e $R"						v0.1"

#banner
echo -e $G "What is your banner name?"
read varB
echo

#cowsay
echo -e $G "What is your cowsay name?"
read varC
echo

echo "clear">clear.txt
echo "cowsay -f eyes "$varB" | lolcat" >cowsay.txt
echo "figlet "$varC" | lolcat">ban.txt



rm /home/kali/.zshrc
cp .zshrc/home/kali/
clear

cat ".zshrc.txt">>/home/kali/.zshrc
cat "clear.txt">>/home/kali/.zshrc
cat "cowsay.txt">>/home/kali/.zshrc
cat "ban.txt">>/home/kali/.zshrc

rm clear.txt
rm  cowsay.txt
rm  ban.txt

figlet finsh | lolcat
exit


